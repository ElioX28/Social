### If this is your first time running this service
copy & paste ( in terminal ) : 
- git clone https://github.com/Tochey/User_Service.git
- cd server
- npm install 
- npm run server
#### In another terminal tab
- cd client
- npm install
- npm start

### Disclaimer : pushing your .env file IS NOT safe. It is done here to simplify the start up process
### To use the 'test.rest' file, install Rest Client (vsCode Extension) or just use boring postman🫥
