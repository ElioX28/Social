Post Team - MARCUS UK - JEAN TOKAM - KHANH NGUYEN

This is a README created by Marcus Uk for the Post Team. The first push onto github will be the feature: Creating a Post. This will be done before the next sprint
10/25.
How to run 
- git clone (https link copied from gtihub) on local repository
- cd to social
- npm install 
- npm start

